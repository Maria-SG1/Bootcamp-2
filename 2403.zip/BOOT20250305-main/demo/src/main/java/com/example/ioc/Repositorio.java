package com.example.ioc;

public interface Repositorio {

	void guardar();

}