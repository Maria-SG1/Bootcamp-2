package com.example.ioc;

public interface Servicio {

	void guardar();

}