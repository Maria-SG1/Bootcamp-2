package com.example.application.models;

import lombok.Data;
import lombok.Value;

@Data
public class PelisDto {
    private int id;
    private String titulo;
}
