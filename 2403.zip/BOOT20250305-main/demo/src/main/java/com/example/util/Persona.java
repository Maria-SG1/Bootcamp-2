package com.example.util;

public class Persona {
	public int id = 0;
	public String nombre = "Pepe";
	public String apellidos = "Pepe";
	
	public Persona(int id, String nombre) {
		super();
		this.id = id;
		this.nombre = nombre;
	}
	

}
