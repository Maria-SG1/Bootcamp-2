package com.example;

import org.springframework.data.repository.CrudRepository;

public interface PeliculaContRepository extends CrudRepository<PeliculaCont, Integer> {

}
